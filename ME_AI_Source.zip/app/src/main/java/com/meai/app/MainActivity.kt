package com.meai.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Crimson = Color(0xFFB5122B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeAiScreen() }
    }
}

@Composable
fun MeAiScreen() {
    val context = LocalContext.current
    var message by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("ME AI מוכן לעזור. אפשר לשאול שאלה או לפתוח חיפוש ברשת.") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Crimson,
        background = Background,
        surface = Panel
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Background).padding(18.dp)
        ) {
            Text("ME AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("העוזר האישי שלך", color = Crimson, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { item ->
                    Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                        Text(item, color = Color.White, modifier = Modifier.padding(14.dp))
                    }
                }
            }
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("כתוב ל־ME AI") },
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val q = message.trim()
                    if (q.isNotEmpty()) {
                        messages.add("אתה: $q")
                        messages.add("בגרסת ההתחלה אפשר לבצע חיפוש ברשת דרך הכפתור למטה. מנוע AI מלא עדיין לא מחובר.")
                        message = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Crimson)
            ) { Text("שלח") }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="))
                        context.startActivity(intent)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Panel)
                ) { Text("חיפוש ברשת") }
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                        (context as? ComponentActivity)?.startActivityForResult(intent, 100)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Panel)
                ) { Text("בחירת קובץ") }
            }
        }
    }
}
